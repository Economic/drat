# epir

<!-- badges: start -->
<!-- badges: end -->

Collection of functions used at EPI

## Installation

You can install the latest version of epir using drat. Add the EPI repo and install the package:
```r
drat:::add("Economic")
install.packages("epir")
```

Installing via drat allows easy updates. Alternatively you can install the current version from GitHub via devtools 
``` r
# devtools::install_github("economic/epir")
```

## Example

``` r
library(epir)
crosstab(mtcars, cyl, gear)
```

